package example.com.android.favoritetoys;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // COMPLETED (1) Declare a TextView variable called mToysListTextView
    private TextView mToysListTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // COMPLETED (3) Use findViewById to get a reference to the TextView from the layout
        /*
         * Using findViewById, we get a reference to our TextView from xml. This allows us to
         * do things like set the text of the TextView.
         */
        mToysListTextView = (TextView) findViewById(R.id.tv_toy_names);

        // COMPLETED (4) Use the static ToyBox.getToyNames method and store the names in a String array

        String[] toyNames = ToyBox.getToyNames();

        // COMPLETED (5) Loop through each toy and append the name to the TextView (add \n for spacing)

        for (String toyName : toyNames) {
            mToysListTextView.append(toyName + "\n\n\n");
        }
    }
}
