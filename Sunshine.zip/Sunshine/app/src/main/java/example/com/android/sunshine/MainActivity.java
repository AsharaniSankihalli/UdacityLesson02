package example.com.android.sunshine;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView mytextview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mytextview = (TextView) findViewById(R.id.tv_weather_data);

        String[] dummyWeatherData = {
                "Sunny 19C",
                "Cloudy 15C",
                "Stormy 11C",
                "Thunderstorms 9C",
                "Thunderstorms 7C",
                "Rainy 8C",
                "Partly Cloudy 10C",
                "Cloudy 15C",
                "Stormy 11C",
                "Hurricane 9C",
                "Sunny 19C",
                "Cloudy 15C",
                "Stormy 11C",
                "Thunderstorms 9C",
                "Thunderstorms 7C",
                "Rainy 8C",
                "Partly Cloudy 10C",
                "Cloudy 15C",
                "Stormy 11C",
                "Hurricane 9C",


        };

        for (String dummyWeatherDay : dummyWeatherData) {
            mytextview.append(dummyWeatherDay + "\n\n\n");
        }
    }
}
